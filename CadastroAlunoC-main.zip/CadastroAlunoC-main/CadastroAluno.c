#include <stdio.h>
#include <string.h>

// 1. Definição da Estrutura Aluno
typedef struct {
    int matricula;
    char nome[50];
    float nota1;
    float nota2;
    float media;
} Aluno;

// Ponto de entrada do programa
int main() {
    // Declaração da variável do tipo Aluno
    Aluno estudante;

    // Constantes do usuário para simular a entrada (como solicitado)
    // Se fosse um programa real, estas linhas seriam substituídas pela leitura de scanf.
    const char *nome_usuario = "João Marcos Soares";
    const int matricula_usuario = 44982518;
    const float nota1_usuario = 5.3;
    const float nota2_usuario = 2.5;
    // A terceira nota (8.0) é ignorada conforme a estrutura de 2 notas da struct.

    // 2. Entrada de Dados: Atribuindo os dados à struct
    // Usando strcpy para copiar a string do nome
    strncpy(estudante.nome, nome_usuario, 50);
    estudante.nome[49] = '\0'; // Garantir terminação da string
    
    // Atribuindo os valores numéricos
    estudante.matricula = matricula_usuario;
    estudante.nota1 = nota1_usuario;
    estudante.nota2 = nota2_usuario;

    // --- Se a entrada fosse via console (como o enunciado sugere com scanf):
    /*
    printf("--- Cadastro de Alunos ---\n");
    printf("Digite o nome do aluno: ");
    scanf(" %49[^\n]", estudante.nome); 
    printf("Digite a matricula (RGM): ");
    scanf("%d", &estudante.matricula);
    printf("Digite a Nota 1: ");
    scanf("%f", &estudante.nota1);
    printf("Digite a Nota 2: ");
    scanf("%f", &estudante.nota2);
    */

    // 3. Cálculo da Média
    estudante.media = (estudante.nota1 + estudante.nota2) / 2.0;

    // 4. Saída de Dados e Situação

    printf("\n============================================\n");
    printf("             DADOS DO ALUNO\n");
    printf("============================================\n");
    printf("Nome: %s\n", estudante.nome);
    printf("Matricula (RGM): %d\n", estudante.matricula);
    printf("Nota 1: %.1f\n", estudante.nota1);
    printf("Nota 2: %.1f\n", estudante.nota2);
    printf("--------------------------------------------\n");
    printf("Media Final: %.2f\n", estudante.media);

    // Condicional (if/else) para determinar a situação
    printf("Situacao: ");
    if (estudante.media >= 6.0) {
        printf("APROVADO\n");
    } else {
        printf("REPROVADO\n");
    }
    printf("============================================\n");

    return 0;

}
